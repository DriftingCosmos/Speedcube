@echo off
start "" "bin64\speedcube.exe" %*
